<?php get_header() ?>
<main class="layout-col layout-col-main">

	<h2>Рубрики</h2>

	<ul class="secondery-navigation">
		<?php the_category() ?>
		<!-- <?php wp_list_categories( $args ); ?> --> 
    </ul>

</main>

<?php get_footer() ?>