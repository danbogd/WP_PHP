<?php
/*
Template Name: archive
*/
?>


<?php get_header(); ?>
<main class="layout-col layout-col-main">




<div class="secondery-navigation">
<article>
<div>
<div>
<?php if ( have_posts() ) while ( have_posts() ) : the_post(); ?>
<h1>Архив публикаций</h1>

<div>

<h3>По месяцам:</h3>

<ul>
<!-- отображение прошлых записей по месяцам, начиная с первой публикации -->
<?php wp_get_archives('show_post_count=1'); ?>
</ul>

<br />
</div>

<h3>По рубрикам:</h3>
<ul>

 <!-- код вывода списка рубрик -->
<?php wp_list_cats('hierarchical=0&optioncount=1&show_count=1'); ?>
</ul>

<?php endwhile; ?>
</div>
</div>
</article>











		

</main>

<?php get_footer(); ?>