<?php get_header() ?>
<main class="layout-col layout-col-main">
	
	<h1>Index file</h1>

</main>
<?php if (is_active_sidebar('sidebar-blog')): ?>
	<aside class="layout-col layout-col-aside">
		<?php dynamic_sidebar('sidebar-blog') ?>
	</aside>
<?php endif; ?>
<?php get_footer() ?>