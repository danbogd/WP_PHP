<?php 
	get_header();
	the_post(); 
?>
<main class="layout-col layout-col-main">
	<h1><?php the_title() ?></h1>
	<div class="post-full">
		<?php the_post_thumbnail() ?>
		<?php the_content() ?>

		<strong ><p class="price">цена</p>

			<?php if ( get_field('price') ) { ?>
	        	<?php the_field('price'); ?>
	        <?php } ?>
	    </strong>
	</div>
</main>

<?php get_footer() ?>

