<?php get_header() ?>
<main class="layout-col layout-col-main">


<h2>Метки</h2>    


<?php the_tags('<ul class="secondery-navigation"><li>','</li><li>','</li></ul>') ?>
</main>

<?php get_footer() ?>