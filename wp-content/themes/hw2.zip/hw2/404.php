<?php get_header() ?>

<main class="layout-col layout-col-full">

	<h1>Ошибка 404. Страница не найдена.</h1>
	
</main>


<?php get_footer() ?>